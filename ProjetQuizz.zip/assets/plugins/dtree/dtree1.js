$(document).ready(function() {
    $(".dTree").dTree();
});